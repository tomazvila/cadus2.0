const fs = require('fs');
const crypto = require('crypto');
const D = __dirname;
const raw = name => fs.readFileSync(`${D}/${name}`, 'utf8');
const read = name => JSON.parse(raw(name));
const sha = x => 'sha256:' + crypto.createHash('sha256').update(x).digest('hex');
const sorted = v => Array.isArray(v) ? v.map(sorted) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, sorted(v[k])])) : v;
const canon = v => JSON.stringify(sorted(v));
const hash = v => sha(canon(v));
const eq = (a,b) => canon(a) === canon(b);
const snapshot = read('FINAL-CONTENT-SNAPSHOT.json');
const O = snapshot.roots.original, S = snapshot.roots.staged;
const teach = read('ACCEPTED-TEACH-REPAIRS.json');
const companionAcceptance = read('ACCEPTED-COMPANION-REPAIRS-v3.json');
const companion = read('COMPANION-REPAIR-PAYLOAD-v3.json');
const finiteAcceptance = read('ACCEPTED-FINITE-REPAIRS-v6.json');
const finite = read('FINITE-POLICY-IMPLEMENTATION-v6.json');
const issues = [];
const assert = (ok, detail) => { if (!ok) issues.push(detail); };
assert(sha(raw('COMPANION-REPAIR-PAYLOAD-v3.json')) === companionAcceptance.candidate_sha256, 'Companion payload acceptance hash mismatch');
assert(sha(raw('FINITE-POLICY-IMPLEMENTATION-v6.json')) === finiteAcceptance.candidate_sha256, 'Finite payload acceptance hash mismatch');
const expected = {...O.files};
for (const [path, payload] of Object.entries(companion)) {
  if (!(path in expected)) continue;
  for (const edit of payload.edits || []) {
    const occurrences = expected[path].split(edit.old).length - 1;
    assert(occurrences === 1, `Companion original binding ${path} ${edit.kp_id}: ${occurrences} occurrences`);
    if (occurrences === 1) expected[path] = expected[path].replace(edit.old, edit.new);
  }
}
const templatePath = 'docs/content-foundations/whole-course-teach/inputs/templates.json';
const expectedTemplates = JSON.parse(expected[templatePath]);
const templateMap = new Map(expectedTemplates.map(r => [r.kp_id,r]));
const draftPaths = Object.keys(O.files).filter(p => /\/drafts\/part-\d+\.json$/.test(p)).sort();
const expectedDraftFiles = Object.fromEntries(draftPaths.map(p => [p,JSON.parse(expected[p])]));
const expectedDraftMap = new Map(Object.values(expectedDraftFiles).flat().map(r => [r.kp_id,r]));
for (const t of teach.rows.filter(r => r.decision === 'approve')) {
  const row = expectedDraftMap.get(t.kp_id);
  assert(!!row, `Missing approved Teach ${t.kp_id}`);
  if (row) row.arguments = t.final_replacement_arguments;
}
for (const t of finite.targets) {
  const tm = templateMap.get(t.kp_id), dr = expectedDraftMap.get(t.kp_id);
  assert(eq(tm,t.original_template), `Finite original template differs: ${t.kp_id}`);
  assert(eq(dr,t.original_teach), `Finite original Teach differs: ${t.kp_id}`);
  if (tm) { for (const k of Object.keys(tm)) delete tm[k]; Object.assign(tm,t.replacement_template); }
  if (dr) { for (const k of Object.keys(dr)) delete dr[k]; Object.assign(dr,t.replacement_teach); }
}
function jsonEnd(text,start) {
  let depth=0, quoted=false, escape=false;
  for (let i=start;i<text.length;i++) {
    const c=text[i];
    if (quoted) { if (escape) escape=false; else if (c==='\\') escape=true; else if (c==='"') quoted=false; }
    else if (c==='"') quoted=true;
    else if (c==='{') depth++;
    else if (c==='}' && --depth===0) return i+1;
  }
  throw Error('Unclosed JSON-shaped YAML object');
}
function stanzas(text) {
  const result=[];
  const topics=[...text.matchAll(/^  - id: ([^\r\n]+)\r?$/gm)];
  for (let i=0;i<topics.length;i++) {
    const topic=topics[i], end=topics[i+1]?.index??text.length;
    const slice=text.slice(topic.index,end);
    const kps=[...slice.matchAll(/^      - id: (kp\d+)\r?$/gm)];
    for(let j=0;j<kps.length;j++) {
      const lo=topic.index+kps[j].index, hi=j+1<kps.length?topic.index+kps[j+1].index:end;
      result.push({kp_id:topic[1].trim()+'/'+kps[j][1],lo,hi,flow:false,text:text.slice(lo,hi)});
    }
  }
  for (const topic of text.matchAll(/^  \{"id": "([^"]+)"/gm)) {
    const start=topic.index+2, end=jsonEnd(text,start), slice=text.slice(start,end);
    const arrayMatch=/"knowledge_points"\s*:\s*\[/.exec(slice);
    if (!arrayMatch) continue;
    let cursor=start+arrayMatch.index+arrayMatch[0].length;
    while (cursor<end) {
      while (/[\s,]/.test(text[cursor])) cursor++;
      if(text[cursor]===']') break;
      if(text[cursor]!=='{') throw Error('Unexpected knowledge-point JSON entry');
      const lo=cursor,hi=jsonEnd(text,lo),kp=JSON.parse(text.slice(lo,hi));
      result.push({kp_id:topic[1]+'/'+kp.id,lo,hi,flow:true,text:text.slice(lo,hi)});
      cursor=hi;
    }
  }
  return result.sort((a,b)=>a.lo-b.lo);
}
const finiteReviewRef = sha(raw('ACCEPTED-FINITE-REPAIRS-v6.json'));
for (const target of finite.targets.filter(t=>t.finite_objective_domain)) {
  const path=target.source.curriculum_path, text=expected[path];
  const stanza=stanzas(text).find(s=>s.kp_id===target.kp_id);
  assert(!!stanza, `Missing finite curriculum stanza ${target.kp_id}`);
  if (!stanza) continue;
  assert(sha(stanza.text)===target.source.original_stanza_sha256, `Finite curriculum source hash mismatch ${target.kp_id}`);
  const policy={...target.finite_objective_domain,review_ref:finiteReviewRef};
  let replacement;
  if (stanza.flow) {
    const obj=JSON.parse(stanza.text); obj.finite_objective_domain=policy;
    // Semantic comparison below accommodates the author's whitespace preservation.
    replacement=JSON.stringify(obj);
  } else {
    const lineEnd=stanza.text.indexOf('\n')+1;
    replacement=stanza.text.slice(0,lineEnd)+'        finite_objective_domain: '+JSON.stringify(policy)+'\n'+stanza.text.slice(lineEnd);
  }
  expected[path]=text.slice(0,stanza.lo)+replacement+text.slice(stanza.hi);
}
function stanzaValue(s) {
  if(s.flow) return JSON.parse(s.text);
  // Only generated finite policy JSON whitespace may differ; all other bytes remain bound.
  return s.text.replace(/^        finite_objective_domain: (.+)$/gm,(_,v)=>'        finite_objective_domain: '+canon(JSON.parse(v)));
}
function outside(text, ss) {
  let out='',last=0;for(const s of ss){out+=text.slice(last,s.lo)+`<KP:${s.kp_id}>`;last=s.hi;}return out+text.slice(last);
}
const curriculumPaths=Object.keys(O.files).filter(p=>p.startsWith('curriculum/')).sort();
const originalStanzas=new Map(), stagedStanzas=new Map(), curriculumRows=[], curriculumContextGuards=[];
for(const path of curriculumPaths) {
  const o=stanzas(O.files[path]),s=stanzas(S.files[path]),e=stanzas(expected[path]);
  assert(eq(o.map(x=>x.kp_id),s.map(x=>x.kp_id)),`Curriculum coverage/order changed: ${path}`);
  assert(outside(O.files[path],o)===outside(S.files[path],s),`Curriculum context outside KP stanzas changed: ${path}`);
  curriculumContextGuards.push({path,original_outside_kp_stanzas_sha256:sha(outside(O.files[path],o)),current_outside_kp_stanzas_sha256:sha(outside(S.files[path],s)),unchanged:outside(O.files[path],o)===outside(S.files[path],s)});
  const sm=new Map(s.map(x=>[x.kp_id,x])),em=new Map(e.map(x=>[x.kp_id,x]));
  for(const row of o) {
    const sr=sm.get(row.kp_id),er=em.get(row.kp_id);
    originalStanzas.set(row.kp_id,row);if(sr)stagedStanzas.set(row.kp_id,sr);
    const matches=!!sr&&!!er&&eq(stanzaValue(sr),stanzaValue(er));
    assert(matches,`Curriculum differs from exact accepted edits: ${row.kp_id}`);
    curriculumRows.push({kp_id:row.kp_id,path,original_stanza_sha256:sha(row.text),current_stanza_sha256:sr?sha(sr.text):null,original_context_unchanged:!!sr&&row.text===sr.text,accepted_expected_content_matches:matches});
  }
}
const allowedCurriculum=[...new Set([...companionAcceptance.additional_curriculum_fixes.map(r=>r.kp_id),...finite.targets.filter(r=>r.finite_objective_domain).map(r=>r.kp_id)])].sort();
const changedCurriculum=curriculumRows.filter(r=>!r.original_context_unchanged).map(r=>r.kp_id).sort();
assert(eq(changedCurriculum,allowedCurriculum),'Changed curriculum KP set differs from accepted companion v3 and finite v6 KPs');
const originalTemplates=JSON.parse(O.files[templatePath]),stagedTemplates=JSON.parse(S.files[templatePath]);
const originalTemplateMap=new Map(originalTemplates.map(r=>[r.kp_id,r])),stagedTemplateMap=new Map(stagedTemplates.map(r=>[r.kp_id,r]));
assert(originalTemplates.length===809&&stagedTemplates.length===809,'Expected 809 original/current selected templates');
assert(eq(originalTemplates.map(r=>r.kp_id),stagedTemplates.map(r=>r.kp_id)),'Selected-template KP order/coverage changed');
const approvedTeach=new Set(teach.rows.filter(r=>r.decision==='approve').map(r=>r.kp_id));
const approvedCompanion=new Set(companionAcceptance.rows.filter(r=>r.decision==='approve').map(r=>r.kp_id));
const approvedFinite=new Set(finiteAcceptance.accepted_kp_ids);
const expectedAffected=new Set([...approvedTeach,...approvedCompanion,...approvedFinite]);
assert(expectedAffected.size===70,'Expected 70 accepted formerly held KPs');
const bindingFiles=['ACCEPTED-TEACH-REPAIRS.json','ACCEPTED-COMPANION-REPAIRS-v3.json','ACCEPTED-FINITE-REPAIRS-v6.json'];
const provenance=kp=>bindingFiles.filter((_,i)=>[approvedTeach,approvedCompanion,approvedFinite][i].has(kp));
const selectedRows=stagedTemplates.map((row,i)=>{
  const original=originalTemplateMap.get(row.kp_id),wanted=templateMap.get(row.kp_id);
  const matches=eq(row,wanted);assert(matches,`Selected template differs from accepted expected row: ${row.kp_id}`);
  return {kp_id:row.kp_id,index:i,path:templatePath,current_row_sha256:sha(JSON.stringify(row)),current_canonical_row_sha256:hash(row),original_canonical_row_sha256:hash(original),changed:!eq(row,original),accepted_expected_row_matches:matches,acceptance_artifacts:provenance(row.kp_id)};
});
const packets=Object.fromEntries(draftPaths.map(p=>[p,read('packets/'+p.split('/').pop())]));
const draftRows=[];
for(const path of draftPaths){
  const o=JSON.parse(O.files[path]),s=JSON.parse(S.files[path]);
  assert(eq(o.map(r=>r.kp_id),s.map(r=>r.kp_id)),`Draft KP order/coverage changed: ${path}`);
  for(let i=0;i<s.length;i++){
    const row=s[i],original=o[i],wanted=expectedDraftMap.get(row.kp_id),packet=packets[path].rows.find(r=>r.kp_id===row.kp_id);
    const matches=eq(row,wanted);assert(matches,`Draft differs from accepted expected row: ${row.kp_id}`);
    assert(packet&&eq(packet.draft,original),`Original draft no longer matches independent review packet: ${row.kp_id}`);
    const originalTemplate=originalTemplateMap.get(row.kp_id),currentTemplate=stagedTemplateMap.get(row.kp_id);
    assert(packet&&eq(packet.selected_template,originalTemplate),`Original template no longer matches independent review packet: ${row.kp_id}`);
    const os=originalStanzas.get(row.kp_id),ss=stagedStanzas.get(row.kp_id);
    assert(!!os&&!!ss,`Missing curriculum context: ${row.kp_id}`);
    const sameTeach=eq(row,original),sameTemplate=eq(originalTemplate,currentTemplate),sameCurriculum=!!os&&!!ss&&os.text===ss.text;
    draftRows.push({kp_id:row.kp_id,path,index:i,current_row_sha256:sha(JSON.stringify(row)),current_canonical_row_sha256:hash(row),current_arguments_canonical_sha256:hash(row.arguments),original_row_sha256:sha(JSON.stringify(original)),current_selected_template_row_sha256:sha(JSON.stringify(currentTemplate)),current_selected_template_canonical_sha256:hash(currentTemplate),current_curriculum_stanza_sha256:ss?sha(ss.text):null,original_teach_unchanged:sameTeach,original_selected_template_unchanged:sameTemplate,original_curriculum_context_unchanged:sameCurriculum,eligible_to_carry_existing_original_approval:matches&&sameTeach&&sameTemplate&&sameCurriculum,accepted_expected_row_matches:matches,acceptance_artifacts:provenance(row.kp_id),original_packet_bindings:packet?{teach_digest:packet.teach_digest,teach_row_sha256:packet.teach_row_sha256,template_digest:packet.template_digest,template_row_sha256:packet.template_row_sha256}:null});
  }
}
assert(draftRows.length===735,'Expected 735 current draft rows');
assert(new Set(draftRows.map(r=>r.kp_id)).size===735,'Duplicate current draft KPs');
const actualAffected=new Set([...draftRows.filter(r=>!r.original_teach_unchanged).map(r=>r.kp_id),...selectedRows.filter(r=>r.changed).map(r=>r.kp_id),...changedCurriculum]);
assert(eq([...actualAffected].sort(),[...new Set([...expectedAffected,'quadratic-graphs-vertex/kp1'])].sort()),'Affected content KP set differs from 70 accepted KPs plus quadratic vertex typo');
assert(eq(O.historical_archive,S.historical_archive),'Historical archive bytes/paths differ');
assert(eq(O.deployment_configuration,S.deployment_configuration),'Deployment configuration bytes/paths differ');
assert(Object.values(O.file_metadata).every(m=>m.stable_during_read)&&Object.values(S.file_metadata).every(m=>m.stable_during_read),'File changed during snapshot read');
const report={schema_version:1,status:issues.length?'mismatches_require_resolution':'staged_content_matches_independent_acceptances',scope:'Independent offline content approval and verification of source-bound existing native gate receipts; no live publication authority.',reviewer:{identity:'/root/accept_teach_repairs',requested_model:'gpt-6-astra',reasoning_effort:'medium'},snapshot_started_utc:snapshot.snapshot_started_utc,snapshot_completed_utc:snapshot.snapshot_completed_utc,snapshot_file_sha256:sha(raw('FINAL-CONTENT-SNAPSHOT.json')),roots:{original:O.root,staged:S.root},acceptance_artifact_sha256:Object.fromEntries(bindingFiles.map(p=>[p,sha(raw(p))])),hash_semantics:{current_row_sha256:'SHA-256 of JavaScript JSON.stringify(row), retaining parsed key order',canonical_sha256:'SHA-256 of UTF-8 JSON with recursively sorted object keys, compact separators, Unicode unescaped',curriculum_stanza_sha256:'SHA-256 of exact UTF-8 source stanza bytes'},carry_forward_rule:'An existing original independent approval may be carried forward only on rows marked eligible_to_carry_existing_original_approval. This flag proves unchanged Teach, selected template, curriculum KP stanza, and global/topic context; it does not create an approval where none existed. Changed context requires the listed new acceptance artifact and exact current hashes. Any later change to draft, template, relevant curriculum stanza, surrounding topic/global context, or acceptance artifact invalidates the corresponding receipt.',counts:{draft_rows:draftRows.length,selected_templates:selectedRows.length,curriculum_kps:curriculumRows.length,changed_drafts:draftRows.filter(r=>!r.original_teach_unchanged).length,changed_selected_templates:selectedRows.filter(r=>r.changed).length,changed_curriculum_kps:changedCurriculum.length,accepted_formerly_held_kps:expectedAffected.size,affected_content_kps:actualAffected.size,original_approval_context_preserved:draftRows.filter(r=>r.eligible_to_carry_existing_original_approval).length},curriculum_changed_kps:changedCurriculum,historical_archive:{unchanged:eq(O.historical_archive,S.historical_archive),file_count:Object.keys(S.historical_archive).length,current_files:S.historical_archive},deployment_configuration:{unchanged:eq(O.deployment_configuration,S.deployment_configuration),scope:'All files in discovered top-level deploy*/infra*/nix/nixos* paths, Dockerfile*/compose*/docker-compose*/flake files, .dockerignore and .github/workflows; no live deployment inspected.',current_files:S.deployment_configuration},source_file_snapshot_metadata:S.file_metadata,issues,draft_rows:draftRows,selected_template_rows:selectedRows,curriculum_rows:curriculumRows};
report.curriculum_context_guards=curriculumContextGuards;
fs.writeFileSync(`${D}/FINAL-CONTENT-ACCEPTANCE.json`,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,counts:report.counts,issues},null,2));
