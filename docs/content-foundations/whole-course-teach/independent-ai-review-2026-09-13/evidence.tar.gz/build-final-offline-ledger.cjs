const fs=require('fs'),crypto=require('crypto'),path=require('path');
const D=__dirname,raw=p=>fs.readFileSync(path.join(D,p)),read=p=>JSON.parse(raw(p));
const sha=b=>'sha256:'+crypto.createHash('sha256').update(b).digest('hex');
const sort=v=>Array.isArray(v)?v.map(sort):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,sort(v[k])])):v;
const canonical=v=>JSON.stringify(sort(v)),hash=v=>sha(canonical(v)),equal=(a,b)=>canonical(a)===canonical(b);
const audit=read('FINAL-CONTENT-ACCEPTANCE.json'),snapshot=read('FINAL-CONTENT-SNAPSHOT.json');
const originals=read('ALL-DECISIONS.json'),reconciled=read('RECONCILED-DECISIONS.json');
const teach=read('ACCEPTED-TEACH-REPAIRS.json'),companion=read('ACCEPTED-COMPANION-REPAIRS-v3.json'),finite=read('ACCEPTED-FINITE-REPAIRS-v6.json');
const whole=read('whole735-technical-accepted-v6.json'),native=read('repaired71-instruction-output-accepted-v6.json'),nativeInput=read('repaired71-instruction-input-v2.json');
const map=rows=>new Map(rows.map(r=>[r.kp_id,r]));
const originalMap=map(originals.decisions),reconciledMap=map(reconciled.decisions),teachMap=map(teach.rows.filter(r=>r.decision==='approve')),companionMap=map(companion.rows),finiteMap=map(finite.targets),wholeMap=map(whole.rows),nativeMap=map(native.documents);
const currentDrafts=map(Object.entries(snapshot.roots.staged.files).filter(([p])=>p.includes('/drafts/')).flatMap(([,t])=>JSON.parse(t)));
const currentTemplates=map(JSON.parse(snapshot.roots.staged.files['docs/content-foundations/whole-course-teach/inputs/templates.json']));
const issues=[...audit.issues],check=(ok,msg)=>{if(!ok)issues.push(msg);};
check(['staged_content_matches_independent_acceptances','final_content_and_gate_bindings_accepted_offline'].includes(audit.status),'Content audit did not pass');
for(const [p,h]of Object.entries(whole.raw_input_sha256))check(snapshot.roots.staged.file_metadata['docs/content-foundations/whole-course-teach/'+p]?.sha256===h,'Whole735 source input binding mismatch: '+p);
check(equal(snapshot.roots.staged.all_gate_curriculum_source_hashes,whole.curriculum_raw_input_sha256),'Whole735 full curriculum input binding mismatch');
check(whole.rows.length===735&&whole.rows.every(r=>r.production_gate==='accepted'),'Whole735 production gates not all accepted');
check(native.documents.length===71&&native.documents.every(r=>r.accepted===true&&r.exhaustive===true),'Repaired71 gates are not 71 accepted/exhaustive');
check(native.curriculum_hash===whole.curriculum_hash,'Native71 and Whole735 curriculum hashes differ');
check(sha(raw('repaired71-instruction-input-v2.json'))==='sha256:'+native.input_sha256,'Native71 exact instruction-input hash mismatch');
for(const r of nativeInput.documents)check(equal(r,currentDrafts.get(r.kp_id)),'Native71 Teach input differs from snapshot: '+r.kp_id);
for(const r of nativeInput.templates)check(equal(r,currentTemplates.get(r.kp_id)),'Native71 template input differs from snapshot: '+r.kp_id);
check(equal(nativeInput.documents.map(r=>r.kp_id).sort(),native.documents.map(r=>r.kp_id).sort()),'Native71 output/input KP coverage mismatch');
const affected=[...new Set([...teachMap.keys(),...companionMap.keys(),...finiteMap.keys()])].sort();
check(affected.length===70,'Accepted revised prior-hold union is not 70');
check(equal([...nativeMap.keys()].sort(),[...affected,'quadratic-graphs-vertex/kp1'].sort()),'Native71 does not exactly cover revised70 plus vertex context');
check(raw('whole-course-teach-accepted-v6.log').toString().includes('test result: ok. 3 passed; 0 failed;'),'Recorded whole_course_teach regression log is not 3/3 passed');
const rawReviewManifest=[];
for(const batch of originals.batches){
 const p='reviews/'+batch.batch_id+'.json',data=raw(p),r=JSON.parse(data);
 check(sha(data)===batch.review_file_sha256,'Historical raw review changed: '+p);
 check(snapshot.roots.original.file_metadata['docs/content-foundations/whole-course-teach/drafts/'+batch.batch_id+'.json']?.sha256===batch.source_file_sha256,'Original source differs from raw review binding: '+batch.batch_id);
 rawReviewManifest.push({path:p,sha256:sha(data),batch_id:batch.batch_id,reviewer:batch.reviewer,reasoning_effort:batch.reasoning_effort,source_file_sha256:batch.source_file_sha256});
 for(const row of r.decisions)check(equal(row.checks,originalMap.get(row.kp_id)?.checks)&&row.decision===originalMap.get(row.kp_id)?.decision,'Raw/aggregate decision differs: '+row.kp_id);
}
const names=['independent_math_recomputation','objective_and_constraints','explanations','hints_and_leakage'];
const vertexFix=companion.additional_curriculum_fixes.find(r=>r.kp_id==='quadratic-graphs-vertex/kp1');
const curriculumMap=map(audit.curriculum_rows),globalContext=new Map(audit.curriculum_context_guards.map(r=>[r.path,r]));
const artifact=p=>({path:p,sha256:sha(raw(p))});
const evidenceFiles=['ALL-DECISIONS.json','RECONCILED-DECISIONS.json','POLICY-RECONCILIATION-approved.json','POLICY-RECONCILIATION-held.json','finite-policies.json','ACCEPTED-TEACH-REPAIRS.json','ACCEPTED-COMPANION-REPAIRS-v3.json','ACCEPTED-FINITE-REPAIRS-v6.json','whole735-technical-accepted-v6.json','repaired71-instruction-input-v2.json','repaired71-instruction-output-accepted-v6.json','whole-course-teach-accepted-v6.log'];
const decisions=audit.draft_rows.map(binding=>{
 const kp=binding.kp_id,original=originalMap.get(kp),base=reconciledMap.get(kp),gate=wholeMap.get(kp),provenance=[{...artifact('reviews/'+base.batch_id+'.json'),role:'historical_raw_independent_review',decision:original.decision,reviewer:original.reviewer},{...artifact('RECONCILED-DECISIONS.json'),role:'original_source_policy_reconciled_review',decision:base.decision,row_canonical_sha256:hash(base)}];
 let decision='quarantine',basis='unresolved',checks=base.checks,reason='No eligible approval has been established for the current source context.';
 if(binding.eligible_to_carry_existing_original_approval&&base.decision==='approve'){
  decision='approve';basis=base.reconciliation?'unchanged_context_policy_reconciled_approval':'unchanged_context_original_approval';reason='Original independent approval carried forward after exact Teach, selected-template, curriculum-stanza, and surrounding-context preservation checks.';
 }
 if(teachMap.has(kp)){
  const t=teachMap.get(kp);checks=t.checks;decision='approve';basis='independently_accepted_teach_replacement';reason='Exact final Teach arguments match the independently recomputed four-pass replacement; own assessment and curriculum context are source-bound.';
  provenance.push({...artifact('ACCEPTED-TEACH-REPAIRS.json'),role:'accepted_teach_replacement',row_canonical_sha256:hash(t),reviewer:t.reviewer});
 }
 if(companionMap.has(kp)){
  const c=companionMap.get(kp),extra=companion.additional_teach_fixes.find(r=>r.kp_id===kp),cc=c.checks;
  const explanation=base.checks.explanations.evidence+(extra?' Independently accepted Teach correction: '+extra.evidence:'');
  checks={independent_math_recomputation:{status:cc.mathematical_recomputation.status,evidence:cc.mathematical_recomputation.evidence+(extra?' Teach: '+extra.evidence:' Teach remains unchanged; original computation evidence: '+base.checks.independent_math_recomputation.evidence)},objective_and_constraints:cc.constraint_and_contract_alignment,explanations:{status:'pass',evidence:explanation+' Final template hints/sketch and source mirrors are covered by companion acceptance.'},hints_and_leakage:cc.protected_assessment_separation};
  decision='approve';basis='independently_accepted_companion_context_repair';reason='Exact final companion context matches independent v3 acceptance; any associated Teach correction and curriculum exemplar repair is retained in its acceptance provenance.';
  provenance.push({...artifact('ACCEPTED-COMPANION-REPAIRS-v3.json'),role:'accepted_companion_context',row_canonical_sha256:hash(c),reviewer:companion.reviewer,additional_teach_fix:extra||null,additional_curriculum_fixes:companion.additional_curriculum_fixes.filter(r=>r.kp_id===kp)});
 }
 if(finiteMap.has(kp)){
  const f=finiteMap.get(kp);checks=f.checks;decision='approve';basis='independently_accepted_finite_v6_revision';reason='Exact final Teach, template, and declared finite policy match independent v6 acceptance; v6 supersedes earlier companion exclusions for the two overlapping KPs.';
  provenance.push({...artifact('ACCEPTED-FINITE-REPAIRS-v6.json'),role:'accepted_final_finite_revision',row_canonical_sha256:hash(f),reviewer:finite.reviewer});
 }
 if(kp==='quadratic-graphs-vertex/kp1'){
  check(vertexFix?.decision==='approve','Vertex context correction lacks independent acceptance');
  checks={...base.checks,independent_math_recomputation:{status:'pass',evidence:'Current Teach y=x^2+10x+30 gives x=-10/2=-5 and y=25-50+30=5. The corrected owned exemplar y=x^2+4x+1 gives x=-4/2=-2 and y=4-8+1=-3. Both ordered vertices are correct.'},objective_and_constraints:{status:'pass',evidence:'The sole curriculum change restores the required -b sign for the owned vertex calculation. Teach and selected template remain exactly unchanged; the explicit independently accepted correction preserves the objective and answer.'}};
  decision='approve';basis='original_teach_plus_independently_accepted_vertex_context_fix';reason='Original Teach approval is combined with separate independent acceptance of the owned-example sign correction; source audit confirms the exact bounded curriculum change.';
  provenance.push({...artifact('ACCEPTED-COMPANION-REPAIRS-v3.json'),role:'separate_vertex_curriculum_correction',accepted_fix:vertexFix});
 }
 if(base.reconciliation)provenance.push({...artifact(path.basename(base.reconciliation.raw_evidence)),role:'exact_finite_policy_reconciliation',original_decision:base.original_decision||original.decision,reconciliation:base.reconciliation});
 check(decision==='approve','No applicable independent approval for '+kp);
 check(names.every(n=>checks[n]?.status==='pass'&&checks[n]?.evidence?.trim()),'Four substantive checks missing or failing for '+kp);
 check(binding.accepted_expected_row_matches&&gate?.production_gate==='accepted','Current row/gate binding failed for '+kp);
 const curriculum=curriculumMap.get(kp),context={draft_path:binding.path,draft_index:binding.index,teach_row_sha256:binding.current_row_sha256,teach_row_canonical_sha256:binding.current_canonical_row_sha256,teach_arguments_canonical_sha256:binding.current_arguments_canonical_sha256,template_row_sha256:binding.current_selected_template_row_sha256,template_row_canonical_sha256:binding.current_selected_template_canonical_sha256,curriculum_path:curriculum.path,curriculum_stanza_sha256:binding.current_curriculum_stanza_sha256,curriculum_surrounding_context_sha256:globalContext.get(curriculum.path).current_outside_kp_stanzas_sha256,teach_digest:gate.teach_digest,template_digest:gate.template_digest};
 return {kp_id:kp,decision,basis,reason,checks,source_context:context,source_context_canonical_sha256:hash(context),original_decision:original.decision,reconciled_original_decision:base.decision,original_context_carried_forward:binding.eligible_to_carry_existing_original_approval,original_bindings:binding.original_packet_bindings,provenance,technical_gate:{whole735:{artifact:'whole735-technical-accepted-v6.json',production_gate:gate.production_gate,collision:gate.collision,ai_review_field_preserved:gate.ai_review},repaired71:nativeMap.get(kp)||null},reviewer:{identity:'/root/accept_teach_repairs',requested_model:'gpt-6-astra',reasoning_effort:'medium',role:'independent final source-integration auditor; original substantive reviewers retained in provenance'}};
});
check(decisions.length===735&&new Set(decisions.map(r=>r.kp_id)).size===735,'Final ledger count/uniqueness differs from 735');
check(equal(decisions.filter(r=>r.reconciled_original_decision!=='approve').map(r=>r.kp_id).sort(),affected),'Accepted replacement union differs from exact 70 reconciled holds');
if(issues.length)for(const row of decisions){row.decision='quarantine';row.reason='Final audit has unresolved global integrity issues; see ledger issues.';}
audit.status=issues.length?'final_content_integrity_issues':'final_content_and_gate_bindings_accepted_offline';
audit.issues=issues;
audit.native_gate_bindings={whole735:{...artifact('whole735-technical-accepted-v6.json'),current_raw_inputs_match:true,current_all_96_curriculum_input_hashes_match:true,accepted:whole.rows.filter(r=>r.production_gate==='accepted').length,original_status:whole.status,ai_review_fields:'Original pending fields preserved; this offline ledger does not mutate serving approval.'},repaired71:{...artifact('repaired71-instruction-output-accepted-v6.json'),input:artifact('repaired71-instruction-input-v2.json'),current_input_rows_match:issues.every(x=>!x.startsWith('Native71')),accepted_exhaustive:native.documents.filter(r=>r.accepted&&r.exhaustive).length},whole_course_teach:{...artifact('whole-course-teach-accepted-v6.log'),recorded_result:'3 passed; 0 failed',execution:'Existing parent-run log inspected; this auditor did not rerun tests.'}};
audit.historical_raw_review_manifest=rawReviewManifest;
audit.final_revision_scope={teach_approved:42,companion_v3_approved:17,finite_v6_approved:13,companion_finite_overlap:['cube-roots/kp1','difference-of-squares/kp1'],unique_prior_holds_resolved:70,separate_vertex_context_correction:1,original_contexts_preserved:664,earlier_policy_rejections_cleared:3};
fs.writeFileSync(path.join(D,'FINAL-CONTENT-ACCEPTANCE.json'),JSON.stringify(audit,null,2)+'\n');
const ledger={schema_version:1,status:issues.length?'offline_ledger_quarantined':'all_735_independently_approved_offline',scope:'Offline independent source-content approval for the exact isolated snapshot. No live serving approval, AI/API approval mutation, publication, deployment, or original raw-review modification has been performed.',snapshot_started_utc:snapshot.snapshot_started_utc,snapshot_completed_utc:snapshot.snapshot_completed_utc,source_roots:audit.roots,source_snapshot:artifact('FINAL-CONTENT-SNAPSHOT.json'),final_content_acceptance:artifact('FINAL-CONTENT-ACCEPTANCE.json'),technical_source_commit:originals.technical_source_commit,original_canonical_curriculum_hash:originals.canonical_curriculum_hash,current_canonical_curriculum_hash:whole.curriculum_hash,counts:{approve:decisions.filter(r=>r.decision==='approve').length,reject:0,quarantine:decisions.filter(r=>r.decision==='quarantine').length},approval_accounting:audit.final_revision_scope,raw_reviews_preserved:true,live_approvals_applied:false,production_api_calls:false,deployed:false,gate_execution:'Inspected and source-bound existing parent-run gate outputs; no tests executed by this auditor.',invalidation_rule:'Any change to a row, its selected template, its curriculum stanza, surrounding curriculum context, or bound acceptance evidence invalidates that row receipt. Full-source hashes additionally bind the exact native gate snapshot.',bound_artifacts:evidenceFiles.map(artifact),original_raw_review_manifest:rawReviewManifest,issues,decisions};
fs.writeFileSync(path.join(D,'FINAL-735-DECISIONS.json'),JSON.stringify(ledger,null,2)+'\n');
const candidates=[...rawReviewManifest.map(r=>r.path),...rawReviewManifest.map(r=>'packets/'+r.batch_id+'.json'),...evidenceFiles,'REVIEWER-INSTRUCTIONS.md','COMPANION-REPAIR-PAYLOAD-v3.json','FINITE-POLICY-IMPLEMENTATION-v6.json','FINAL-CONTENT-SNAPSHOT.json','FINAL-CONTENT-ACCEPTANCE.json','FINAL-735-DECISIONS.json','audit-final-content.cjs','build-final-offline-ledger.cjs'];
const files=[...new Set(candidates)].map(p=>({...artifact(p),size_bytes:raw(p).length,destination_relative_path:p}));
const bundle={status:'proposal_only_not_copied',destination:'docs/content-foundations/whole-course-teach/independent-ai-review-2026-09-13',scope:'Self-contained offline content-review evidence: immutable raw reviews and original packets, their aggregate and policy reconciliations, final independent revision acceptances and exact content payloads, original/final source snapshot, source-bound native content gates, final audit, final ledger, and reproducible audit scripts.',raw_review_policy:'Copy raw bytes unchanged and preserve hashes. Historical review verdicts remain intact; revised decisions live in the final ledger.',reproduce_from_bundled_snapshot:['node audit-final-content.cjs','node build-final-offline-ledger.cjs'],live_approval:false,files,total_size_bytes:files.reduce((n,f)=>n+f.size_bytes,0),optional_development_history:'Earlier rejected proposals, superseded payload versions, temporary diagnostics, build caches, and native dump code are not needed for this final content evidence bundle. Their historical references/hashes remain in immutable acceptance artifacts.',additional_gate_scope:'Disjoint unit06/unit07 implementation/regression evidence can be attached separately after completion; it is outside this 735-row content ledger.'};
fs.writeFileSync(path.join(D,'FINAL-EVIDENCE-BUNDLE-PROPOSAL.json'),JSON.stringify(bundle,null,2)+'\n');
console.log(JSON.stringify({status:ledger.status,counts:ledger.counts,issues,bundle_files:files.length,bundle_bytes:bundle.total_size_bytes},null,2));
