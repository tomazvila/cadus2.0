#!/usr/bin/env python3
"""Apply the source-bound Unit06 evidence lifecycle candidate; never generates review evidence."""
import argparse,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);a=p.parse_args();root=a.root.resolve(strict=True)
plan=json.loads((D/'UNIT06-EVIDENCE-REGRESSION-REPAIR.json').read_text());payload=json.loads((D/'UNIT06-EVIDENCE-REGRESSION-PAYLOAD.json').read_text())
def sha(b):return 'sha256:'+hashlib.sha256(b).hexdigest()
assert set(plan['files'])==set(payload)
changes=[]
for rel,e in payload.items():
 path=root/rel;assert path.resolve().is_relative_to(root) and not path.is_symlink(),rel
 out=e['contents'].encode();assert sha(out)==e['after_sha256']==plan['files'][rel]['after_sha256'],rel
 before=sha(path.read_bytes()) if path.exists() else None
 if before==e['after_sha256']:continue
 assert before==e['before_sha256']==plan['files'][rel]['before_sha256'],f'Source drift: {rel}'
 changes.append((path,out))
# Historical evidence is checked even though this patch never writes those files.
for rel,e in plan['historical_preservation'].items():
 if rel in payload:continue
 assert sha((root/rel).read_bytes())==e['sha256'],'Historical evidence drift: '+rel
for path,out in changes:path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(out)
print(json.dumps({'applied':[str(p.relative_to(root)) for p,_ in changes],'next':'Run the native unit06_templates example to produce current-technical.json, then focused Rust and Python tests. Historical receipts are unchanged.'},indent=2))
