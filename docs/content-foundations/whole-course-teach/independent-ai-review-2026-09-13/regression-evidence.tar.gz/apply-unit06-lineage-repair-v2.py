#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();root=a.root.resolve(strict=True)
plan=json.loads((D/'UNIT06-LINEAGE-REPAIR-v2.json').read_text());payload=json.loads((D/'UNIT06-LINEAGE-REPAIR-v2-PAYLOAD.json').read_text())
def sha(b):return 'sha256:'+hashlib.sha256(b).hexdigest()
assert set(plan['files'])==set(payload)
writes=[]
for rel,e in payload.items():
 path=root/rel;assert path.resolve().is_relative_to(root) and not path.is_symlink(),rel
 out=e['contents'].encode();assert sha(out)==e['after_sha256']==plan['files'][rel]['after_sha256'],rel
 before=sha(path.read_bytes()) if path.exists() else None
 if before==e['after_sha256']:continue
 assert before==e['before_sha256']==plan['files'][rel]['before_sha256'],'Source drift: '+rel
 writes.append((path,out))
for path,out in writes:path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(out)
print(json.dumps({'applied':[str(p.relative_to(root)) for p,_ in writes],'content_and_receipts':'unchanged'}))
