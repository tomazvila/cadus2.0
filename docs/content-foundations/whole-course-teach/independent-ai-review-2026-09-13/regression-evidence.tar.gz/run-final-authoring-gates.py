"""Run authoring unit tests with the same native inputs as their CLI entry points."""
import json
import os
from pathlib import Path
import sys
import unittest

root = Path(sys.argv[1]).resolve(strict=True)
receipt = Path(sys.argv[2])
os.chdir(root)
sys.path.insert(0, str(root / 'scripts/authoring'))
suite = unittest.defaultTestLoader.discover(str(root / 'scripts/authoring'), pattern='test_*.py')
facts = str(root / 'target/unit04-complement/after-facts.json')
gate = str(root / 'target/unit04-complement/gate.json')
for name in (
    'test_unit04_complement',
    'test_unit05_residual',
    'test_unit05_residual_second',
    'test_unit05_tail_mixtures',
    'test_unit05_tail_systems',
):
    sys.modules[name].FACTS = facts
sys.modules['test_unit04_complement'].GATE = gate
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = {
    'status': 'passed' if result.wasSuccessful() else 'failed',
    'tests_run': result.testsRun,
    'failures': len(result.failures),
    'errors': len(result.errors),
    'skipped': len(result.skipped),
    'input_setup': 'CLI-required FACTS and GATE globals supplied from fresh native output; assertions unchanged.',
}
with receipt.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
raise SystemExit(0 if result.wasSuccessful() else 1)
